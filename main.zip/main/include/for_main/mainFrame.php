<div class="flex flex-col gap-5 items-center justify-center w-full h-[500px] mt-16">
        <img src="../src/img/mainFrameMain.svg" class="absolute inset-0 mx-auto mt-36 z-0 pr-[100px]" />
        <p class="z-10 text-xl font-bold mt-[111px] w-[260px] text-center">Путешествуйте долго и
                обменивайтесь навыками
        </p>
        <button id="" href="../reg/index.php" class="mt-10 z-10 font-bold bg-[#EEA280] px-11 py-4 text-[#F3FFE7] rounded-full shadow-lg
        hover:shadow-2xl hover:border-solid hover:font-bold transition duration-200">Регистрация</button>
</div>