<div class="flex flex-col gap-5 items-center justify-center h-[500px] mt-9 mx-auto">
        <p class="z-10 text-lg font-medium w-auto text-center">На странице "Навыки & услуги" можно ознакомиться с умениями 
            <br>и услугами пользователей платформы, что поможет им успешно 
            <br>обмениваться навыками во время долгосрочных путешествий</p>
</div>