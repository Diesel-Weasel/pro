import {
    Collapse,
    initTWE,
  } from "tw-elements";
  
  initTWE({ Collapse });