<footer class="bg-[#191919] bottom-0 left-0 fixed flex justify-center items-center w-full">
    <div class="text-center text-white">
    <div class="flex flex-row justify-center text-center text-sm py-4">
            <a href="../conf/policy.php" class="text-sm hover:text-neutral-300 transition duration-200">Политика конфиденциальности</a>
            <p class="ml-8">© 2024</p> 
            <p class="font-bold italic mr-8">- GlobalTradeSkills</p>
            <a href="../conf/agreement.php" class="text-sm text-white hover:text-neutral-300 transition duration-200">Пользовательское соглашение</a>
        </div>
    </div>
</footer>