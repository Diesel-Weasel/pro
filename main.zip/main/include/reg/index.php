<!DOCTYPE html>
<html lang="en">

<head>
        <script src="../modal.js"></script>
        <script src="https://cdn.tailwindcss.com"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
        <link rel="stylesheet" href="/src/style/output.css">
        <link rel="stylesheet" href="/src/style/style.css">
        <script src="https://cdn.tailwindcss.com"></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Регистрация</title>
        <style>
                body {
                        background-image: url(./../src/img/pattern.png);
                        font-family: "Montserrat", sans-serif;
                        font-optical-sizing: auto;
                        font-style: normal;
                }

                #scroll::-webkit-scrollbar {
                        display: none;
                }

                #scroll {
                        scrollbar-width: none;
                }
        </style>
</head>

<body>
        <div class="popup">
                <div class="close-btn">&times;</div>
                <div class="form">
                        <h2>Log in</h2>
                        <div class="form-element">
                                <label for="email">Email</label>
                                <input type="text" id="Email" placeholder="Enter email">
                        </div>
                        <div class="form-element">
                                <label for="password">Password</label>
                                <input type="password" id="password" placeholder="Enter password">
                        </div>
                        <div class="form-element">
                                <input type="checkbox" id="remember-me" placeholder="Enter email">
                                <input for="remember-me">Remember me
                        </div>
                        <div class="form-element">
                                <button>Sign In</button>
                        </div>
                        <div class="form-element">
                                <a href="#">Forgot password?</a>
                        </div>
                </div>
        </div>
</body>

</html>