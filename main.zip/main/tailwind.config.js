/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "/main/*.php",
    "/*/**/*.html",
    "*.js",
  ],
  theme: {
    extend: {},
  },
  plugins: [
  ],
}

